
  # Finance Inventory Management App

  This is a code bundle for Finance Inventory Management App. The original project is available at https://www.figma.com/design/pxKIlVyhn1AzULmhrXEzGB/Finance-Inventory-Management-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  